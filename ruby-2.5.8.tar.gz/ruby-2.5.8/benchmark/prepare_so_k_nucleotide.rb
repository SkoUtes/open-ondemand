require_relative 'make_fasta_output'
prepare_fasta_output(100_000)
